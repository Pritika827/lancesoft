const express = require('express');
const passport = require('passport');
const cookieOptions = require("../config/cookieOptions");
const pool = require("../config/db");
const {post} = require("axios");
const router = express.Router();

// Simple token validation
const validateToken = async (token) => {
    try {
        const response = await fetch('https://graph.microsoft.com/v1.0/me', {
            headers: { 'Authorization': `Bearer ${token}` }
        });
        return response.status === 200;
    } catch (error) {
        console.error('Token validation error:', error);
        return false;
    }
};

// Updated login route with better session handling
router.get('/login', async (req, res, next) => {
    try {
        console.log('Login attempt - Session exists:', !!req.session);
        console.log('User authenticated:', req.isAuthenticated());
        
        // Check if user is already authenticated with valid token
        if (req.isAuthenticated() && req.user?.accessToken) {
            console.log('Found existing session, validating token...');
            
            const isValid = await validateToken(req.user.accessToken);
            
            if (isValid) {
                console.log('Token is valid, redirecting to app...');
                const userInfo = {
                    email: req.user.email,
                    displayName: req.user.displayName,
                    accessToken: req.user.accessToken
                };
                return res.redirect(`${process.env.APP_URL}`);
            } else {
                console.log('Token invalid, clearing session...');
                // Clear invalid session
                req.logout(() => {
                    req.session.destroy(() => {
                        // Initiate new authentication
                        passport.authenticate('openidconnect')(req, res, next);
                    });
                });
                return;
            }
        }

        console.log('No valid session found, starting new auth flow...');
        clearAllCookies(req, res);
        passport.authenticate('openidconnect')(req, res, next);
    } catch (error) {
        console.error('Login route error:', error);
        next(error);
    }
});

const clearAllCookies = (req, res) => {

    // Clear all cookies with different domain variations and paths
    const cookies = ['access_token', 'refresh_token', 'email', 'displayName'];
    const domains = [
        process.env.COOKIES_DOMAIN
    ];
    const paths = ['/'];

    // Clear cookies for all domain and path combinations
    cookies.forEach(cookieName => {
        // Default cookie clear
        res.clearCookie(cookieName);

        // Clear with specific domains and paths
        domains.forEach(domain => {
            paths.forEach(path => {
                res.cookie(cookieName, '', {
                    ...cookieOptions,
                    expires: new Date(0),
                    path: path,
                    domain: domain
                });
            });
        });

        // Also try clearing without domain (for localhost)
        paths.forEach(path => {
            res.cookie(cookieName, '', {
                expires: new Date(0),
                path: path,
                httpOnly: true,
                secure: true,
                sameSite: 'lax'
            });
        });
        console.log("All cookies cleared successfully");
    });
};

// Callback after successful OpenID Connect authentication
router.all('/callback', (req, res, next) => {
    passport.authenticate('openidconnect', async (err, user, info) => {
        if (err) {
            return next(err);
        }
        if (!user || Object.keys(user).length === 0) {
            return res.redirect('/api/v1/login');
        }

        try {
            console.log("Authenticating user:", user.email);

            // Check if user exists in enterprise_users table using email_address column
            const [rows] = await pool.query("SELECT email_address FROM enterprise_users WHERE email_address = ?", [user.email]);

            // Debugging the database result
            console.log("DB Query Result:", rows);

            if (!rows || rows.length === 0) {
                return res.redirect(process.env.CFINDER_REDIRECTION_UNAUTHORIZED_URL);
            }

            console.log("User found in DB:", rows[0].email_address);

            req.logIn(user, async (err) => {
                if (err) {
                    return next(err);
                }

                const allCookies = [
                    { name: 'access_token', value: user.accessToken },
                    { name: 'refresh_token', value: user.refreshToken },
                    { name: 'email', value: user.email },
                    { name: 'displayName', value: user.displayName }
                ];

                allCookies.forEach(cookie => {
                    res.cookie(cookie.name, cookie.value, {
                        ...cookieOptions,
                        domain: process.env.COOKIES_DOMAIN  
                    });
                });

                return res.redirect(process.env.CFINDER_REDIRECTION_URL);
            });

        } catch (err) {
            console.error('MariaDB query error:', err);
            return res.status(500).send('Internal Server Error');
        }
    })(req, res, next);
});

module.exports = router;


// API endpoint to recreate token in Redis
router.get('/recreate-token', async (req, res) => {
    try {
        const token = await refreshAccessToken(req.query.refreshToken);
        if (token.id_token) {
            const allCookies = [
                { name: 'access_token', value: token.id_token }
            ];
            allCookies.forEach(cookie => {
                res.cookie(cookie.name, cookie.value, {
                    ...cookieOptions,
                    domain: process.env.COOKIES_DOMAIN
                });
            });

            res.status(200).send(true);
        } else {
            res.status(500).send("Invalid refresh token received");
        }
    } catch (error) {
        console.error('Error refreshing access token:', error.response ? error.response.data : error.message);
        res.status(500).json({ error: 'Failed to refresh access token' });
    }
});

// Logout endpoint
const axios = require('axios');

router.get('/logout', async (req, res) => {
    console.log("Logging out user:", req.user ? req.user.email : "Unknown User");

    try {
        if (req.user && req.user.accessToken) {
            console.log("Revoking access token...");

            const revokeUrl = `https://login.microsoftonline.com/common/oauth2/v2.0/logout`;
            const tokenURL = process.env.TOKEN_URL;
            const clientID = process.env.CLIENT_ID;
            const clientSecret = process.env.CLIENT_SECRET;

            //Revoke the token
            await axios.post(tokenURL, new URLSearchParams({
                client_id: clientID,
                client_secret: clientSecret,
                token: req.user.accessToken,
                token_type_hint: "access_token"
            }));

            console.log("Access token revoked successfully.");
        }

        //Clear all cookies
        clearAllCookies(req, res);

        //Destroy session
        req.logout(() => {
            req.session.destroy((err) => {
                if (err) {
                    console.error("Error destroying session:", err);
                    return res.status(500).send("Logout failed");
                } else {
                    console.log("Session destroyed successfully");
                    return res.redirect(process.env.CFINDER_REDIRECTION_LOGIN_URL);
                }
            });
        });

    } catch (error) {
        console.error("Logout error:", error.response ? error.response.data : error.message);
        res.status(500).send("Logout failed");
    }
});

// router.get('/logout', (req, res) => {
//     console.log("Logging out user:", req.user ? req.user.email : "Unknown User");

//     req.logout(() => {
//         clearAllCookies(req, res); // Saari cookies delete karein

//         req.session.destroy((err) => {
//             if (err) {
//                 console.error("Error destroying session:", err);
//                 return res.status(500).send("Logout failed");
//             }else{
//             console.log("Session destroyed successfully");

//            // const microsoftLogoutUrl = `https://login.microsoftonline.com/common/oauth2/logout?process.env.CLIENT_ID=${encodeURIComponent(process.env.AUTH_URL)}`;
        
//             return res.redirect(process.env.CFINDER_REDIRECTION_LOGIN_URL);
//             }
//         });
//     });
//});

// Helper function to refresh the access token
const refreshAccessToken = async (refreshToken) => {
    const tokenURL = process.env.TOKEN_URL;
    const clientID = process.env.CLIENT_ID;
    const clientSecret = process.env.CLIENT_SECRET;

    const formData = new FormData();
    formData.append('client_id', clientID);
    formData.append('client_secret', clientSecret);
    formData.append('refresh_token', refreshToken);
    formData.append('grant_type', 'refresh_token');
    formData.append('scope', 'openid profile email'); // Include any additional scopes you need

    const response = await post(tokenURL, formData, {
        headers: {
            'Content-Type': 'multipart/form-data', // This is optional, as FormData sets this automatically
        },
    });

    return response.data;
};

module.exports = router;
