const passport = require('passport');
const OpenIDConnectStrategy = require('passport-openidconnect').Strategy;
require('dotenv').config();

passport.serializeUser((user, done) => {
    done(null, user);
});

passport.deserializeUser((user, done) => {
    done(null, user);
});

passport.use(new OpenIDConnectStrategy({
    issuer: process.env.IDP_ISSUER,
    authorizationURL: process.env.AUTH_URL,
    tokenURL: process.env.TOKEN_URL,
    userInfoURL: process.env.IDP_USER_INFO_URL,
    clientID: process.env.CLIENT_ID,
    clientSecret: process.env.CLIENT_SECRET,
    callbackURL: process.env.BASE_URL + "/api/v1/callback",
    scope: ['openid', 'profile', 'email', 'offline_access'],
    session: false
}, async (issuer, sub, profile, accessToken, idToken, refreshToken, params, done) => {
    try {
        console.log('OpenID Connect callback received:', { profile, accessToken });
        
        // Construct user object with all necessary information
        const user = {
            email: sub.username,
            displayName: sub.displayName,
            accessToken,
            refreshToken,
            idToken
        };

        console.log('Constructed user object:', user);
        return done(null, user);
    } catch (error) {
        console.error('Error in passport strategy:', error);
        return done(error);
    }
}));

module.exports = passport;