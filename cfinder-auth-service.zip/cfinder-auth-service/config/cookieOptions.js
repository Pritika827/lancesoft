const cookieOptions = {
    httpOnly: false,
    secure: true,
    sameSite: 'None',
    path: '/'
};

module.exports = cookieOptions;
