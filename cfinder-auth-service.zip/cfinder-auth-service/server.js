require('dotenv').config();
const express = require('express');
const cors = require('cors');
const passport = require("./config/passportConfiguration");
const cookieParser = require("cookie-parser");
const session = require('express-session');


const app = express();

// List of allowed domains
const allowedOrigins = [
    'https://dev-cfinder.thehummingbird.solutions',
    'https://cfinder.thehummingbird.pro/',
    'http://localhost'
];

app.use(cors({
    origin: function (origin, callback) {
        console.log('Origin:', origin); // Debugging log
        if (!origin || origin.includes("localhost")) {
            return callback(null, true); // Allow non-browser requests (e.g., Postman, mobile apps)
        }
        // Extract domain from origin (ignoring protocol and subdomains)
        const hostname = new URL(origin).hostname;
        const domain = hostname.split('.').slice(-2).join('.'); // Extracts "example.com" from "sub.example.com"

        if (domain === process.env.COOKIES_DOMAIN) {
            return callback(null, true);
        }
        return callback(new Error('Not allowed by CORS'));
    },
    credentials: true, // Allow credentials (cookies, authorization headers, etc.)
    exposedHeaders: ['Set-Cookie'],
    methods: ['GET', 'POST', 'OPTIONS', 'PUT', 'PATCH'],
    allowedHeaders: ['Content-Type', 'Authorization', 'Cookie']
}));

// Add session middleware before passport initialization
app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
}));
app.use(cookieParser());
app.use(passport.initialize());
app.use('/api/v1', require('./routes/authRoutes'));

// Add to server.js
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({
        error: 'Internal Server Error',
        message: err.message
    });
});

app.listen(process.env.PORT, () => {
    console.log(`Server Started on port ${process.env.PORT} in ${process.env.NODE_ENV || ''} mode`);
});
