// const mongoose = require("mongoose");

// const messageSchema = new mongoose.Schema(
//   {
//     messageTo: { type: String, required: true },
//     messageFrom: { type: String, required: true },
//     message: { type: String, required: true },
//     type: { type: String, enum: ["text", "file"], required: true },
//     status: { type: String, enum: ["PENDING", "DELIVERED", "READ"], default: "PENDING" }, // New field
//     timestamp: { type: Date, default: Date.now },
//   },
//   { timestamps: true }
// );

// module.exports = mongoose.model("Messages", messageSchema);


const mongoose = require("mongoose");

const messageSchema = new mongoose.Schema(
  {
    messageTo: { type: String, required: true },
    messageFrom: { type: String, required: true },
    message: { type: String, required: true },
    type: { type: String, enum: ["text", "file"], required: true },
    statusFrom: { 
      type: String, 
      enum: ["PENDING", "DELIVERED", "READ"], 
      default: "PENDING" 
    }, // New field for sender's status
    statusTo: { 
      type: String, 
      enum: ["PENDING", "DELIVERED", "READ"], 
      default: "PENDING" 
    }, // New field for receiver's status
    timestamp: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Messages", messageSchema);
