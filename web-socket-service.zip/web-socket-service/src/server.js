const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const mongoose = require("mongoose");
const socketService = require("../src/services/socketService");
const {getSecrets} = require("./utils/aws_secrets")
const {connectToMongoDB} = require("./config/mongodb")
const path = require('path');
require('dotenv').config();
const app = express();
const server = http.createServer(app);
const io = new Server(server);
const mongodb_certs_filepath="../../global-bundle.pem"
// Middleware
app.use(express.json());

app.use(express.static(path.join(__dirname, 'public')));

const PORT = process.env.PORT || 8084;
const HOST = process.env.HOST || '0.0.0.0';

// app.get('/', (req, res) => {
//   res.sendFile(path.join(__dirname, 'public', 'index.html'));
// });

(
  async () => {

await getSecrets(process.env.SECRET_NAME)

connectToMongoDB(process.env.MONGODB_USER, process.env.MONGODB_PASSWORD, process.env.MONGODB_HOST, process.env.MONGODB_PORT, process.env.MONGODB_DATABASE, mongodb_certs_filepath)
.then(() => {
  
socketService(io); 
server.listen(PORT, HOST, () => console.log(`Server running on port:${PORT}`));
})
.catch((err) => console.error('Connection failed:', err));

})()


