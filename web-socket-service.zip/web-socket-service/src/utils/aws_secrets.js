const { SecretsManagerClient, GetSecretValueCommand } = require('@aws-sdk/client-secrets-manager');

const client = new SecretsManagerClient({ region: 'us-east-1' }); // Replace 'your-region' with your AWS region

/**
 * Retrieve a secret's value from AWS Secrets Manager.
 * @param {string} secretName - The name of the secret.
 * @returns {Promise<Object>} - The secret value as a JSON object.
 */
async function getSecrets(secretName) {
    const command = new GetSecretValueCommand({ SecretId: secretName });

    try {
        const response = await client.send(command);

        if (response.SecretString) {
            await setSecretsAsEnvVariables(JSON.parse(response.SecretString))
        }
    } catch (error) {
        console.error(`Failed to retrieve secret: ${error.message}`);
        throw error;
    }
}

function setSecretsAsEnvVariables(config) {
    process.env["MONGODB_DATABASE"] = config['mongbdb.database'];
    process.env["MONGODB_HOST"] = config['mongodb.host']
    process.env["MONGODB_PORT"] = config['mongodb.port']
    process.env["MONGODB_PASSWORD"] = config['mongbdb.password']
    process.env["MONGODB_USER"] = config['mongodb.user']
}
module.exports = {getSecrets}
