const mongoose = require('mongoose');
const path = require('path');


const connectToMongoDB = async (username, password, host, port, databaseName, sslCertPath) => {
  try {

    const sslCert = path.resolve(__dirname, sslCertPath);

    const uri = `mongodb://${username}:${encodeURIComponent(password)}@${host}:${port}/${databaseName}`;

    const options = {
      tls: !!sslCert,
      authMechanism: 'SCRAM-SHA-1', 
      retryWrites: false,
    };

    
    if (sslCert) {
      options.tlsCAFile = sslCert; 
    }

    await mongoose.connect(uri, options);

    console.log('Successfully connected to MongoDB');
  } catch (error) {
    console.error('Error connecting to MongoDB:', error.message);
    throw error;
  }
};


module.exports = {connectToMongoDB}
