const Message = require("../models/Messages");
const emailService = require("../services/emailService");
const userService = require("./userService");

const hasMessageHistory = async (messageFrom, messageTo) => {
    try {
        const count = await Message.countDocuments({
            $or: [
                { messageTo, messageFrom },
                { messageTo: messageFrom, messageFrom: messageTo }
            ]
        });
        return count > 1;
    } catch (err) {
        console.error("Error checking message history:", err);
        return false;
    }
};

module.exports = {
    handleSendMessage: async (data, socket, io) => {
        try {
            const { messageTo, messageFrom, message, type, globalSetting } = data;
            const recipientOnline = userService.isUserOnline(messageTo);

            const newMessage = new Message({
                messageTo,
                messageFrom,
                message,
                type,
                statusFrom: "PENDING",
                statusTo: recipientOnline ? "DELIVERED" : "PENDING"
            });

            await newMessage.save();

            const chatHistoryExists = await hasMessageHistory(messageFrom, messageTo);
            if (globalSetting && !chatHistoryExists) {
                emailService.sendEmail(messageTo, messageFrom);
            }

            if (recipientOnline) {
                io.to(messageTo).emit("receiveMessage", { 
                    ...data, 
                    statusFrom: "PENDING",
                    statusTo: "DELIVERED", 
                    messageId: newMessage._id 
                });
                socket.emit("messagePENDING", { messageId: newMessage._id, statusTo: "DELIVERED" });
            } else {
                socket.emit("messagePENDING", { messageId: newMessage._id, statusTo: "PENDING" });
            }
        } catch (error) {
            console.error("Error sending message:", error);
        }
    },

    handleMessageDELIVERED: async (messageId, io) => {
        try {
            await Message.findByIdAndUpdate(messageId, { statusTo: "DELIVERED" });
            io.emit("messageDELIVERED", { messageId, statusTo: "DELIVERED" });
        } catch (err) {
            console.error("Error updating message to DELIVERED:", err);
        }
    },

    handleMessageREAD: async (messageId, io) => {
        try {
            const updatedMessage = await Message.findByIdAndUpdate(
                messageId,
                { statusFrom: "DELIVERED", statusTo: "READ" },
                { new: true }
            );

            if (updatedMessage) {
                io.emit("messageREAD", { messageId, statusFrom: "DELIVERED", statusTo: "READ" });
                console.log("Updated message status to 'READ':", messageId);
            }
        } catch (err) {
            console.error("Error updating message to READ:", err);
        }
    },

    handleChatHistory: async (data, socket) => {
        try {
            const { messageTo, messageFrom } = data;
            const messages = await Message.find({
                $or: [
                    { messageTo, messageFrom },
                    { messageTo: messageFrom, messageFrom: messageTo }
                ]
            }).sort({ timestamp: 1 });

            socket.emit("chatHistory", messages);
        } catch (error) {
            console.error("Error fetching chat history:", error);
        }
    },

    handleUserOnline: async (username, io) => {
        try {
            const messages = await Message.find({ messageTo: username, statusTo: "PENDING" });

            messages.forEach(async (message) => {
                await Message.findByIdAndUpdate(message._id, { statusTo: "DELIVERED" });

                io.to(message.messageFrom).emit("messageDELIVERED", { 
                    messageId: message._id, 
                    statusTo: "DELIVERED" 
                });
                io.to(username).emit("receiveMessage", { 
                    ...message.toObject(), 
                    statusTo: "DELIVERED" 
                });
            });
        } catch (err) {
            console.error("Error updating messages to DELIVERED:", err);
        }
    }
};
