const messageService = require("./messageService");
const userService = require("./userService");

module.exports = function (io) {
    io.on("connection", (socket) => {
        console.log("User connected:", socket.id);

        // Handle user login and join room
        socket.on("login", async (username) => {
            socket.join(username); // Use rooms for direct messaging
            userService.handleLogin(socket, username, io);
            
            // Update PENDING messages to DELIVERED if user is online
            await messageService.handleUserOnline(username, io);
        });

        // Handle sending messages
        socket.on("sendMessage", async (data) => {
            console.log("In send message");
            await messageService.handleSendMessage(data, socket, io);
        });

        // Handle fetching chat history
        socket.on("getChatHistory", async (data) => {
            await messageService.handleChatHistory(data, socket);
        });

        // Handle message DELIVERED event
        socket.on("messageDELIVERED", async (messageId) => {
            await messageService.handleMessageDELIVERED(messageId, io);
        });

        // Handle message READ updates
        socket.on("messageREAD", async (messageId) => {
            await messageService.handleMessageREAD(messageId, io);
        });

        // Handle user disconnect
        socket.on("disconnect", () => {
            console.log("User disconnected:", socket.id);
            userService.handleDisconnect(socket, io);
        });
    });
};
