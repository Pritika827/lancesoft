const users = {}; // Store active users: { socketId: username }
const onlineUsers = new Set(); // Store unique online usernames

module.exports = {
    handleLogin: (socket, username, io) => {
        users[socket.id] = username; // Map socket ID to username
        onlineUsers.add(username); // Add username to the online users set
        socket.username = username; // Store username in the socket object

        io.emit("updateUsers", Object.values(users)); // Notify all clients of active users
        io.emit("userOnline", username); // Notify that a user is online
        console.log(`${username} logged in.`);
    },

    handleDisconnect: (socket, io) => {
        const username = users[socket.id];
        if (username) {
            delete users[socket.id]; // Remove user from active list
            onlineUsers.delete(username); // Remove from online users set
            io.emit("updateUsers", Object.values(users)); // Update active users list
            io.emit("userOffline", username); // Notify that a user is offline
            console.log(`${username} disconnected.`);
        }
    },

    isUserOnline: (username) => {
        return onlineUsers.has(username);
    }
};
