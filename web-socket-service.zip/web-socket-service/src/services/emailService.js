const { SESClient, SendEmailCommand } = require('@aws-sdk/client-ses');
require('dotenv').config();
 
// Refined email validation
const isValidEmail = (email) => {
  // Ensure the email isn't empty or undefined and then check its validity
  if (!email || typeof email !== 'string') {
    return false;
  }
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return emailRegex.test(email);
};
 
const sendEmail = async (messageTo, messageFrom) => {
  try {
    // Log the email to debug
    console.log('Email address to be validated:', messageTo);
 
    // Check if the email is valid
    if (!isValidEmail(messageTo)) {
      throw new Error("Invalid email address provided");
    }
 
    // Create SES client with credentials from environment variables
    const sesClient = new SESClient({
      region: process.env.AWS_REGION,
    });
 
    // Define the fixed enterprise name
    const enterpriseName = "Lancesoft";
 
    // Construct email body
    const subject = `You have a Message from ${messageFrom}`;
    const body = `
      <p>Hello ${messageTo},</p>
      <p>${messageFrom}, who is from ${enterpriseName}, is trying to reach out to you. Please click on the button below to connect.</p>
      <div style="text-align: center; margin: 20px;">
        <a href="http://localhost:8084" style="padding: 10px 20px; text-decoration: none; border-radius: 5px;">View Message</a>
      </div>
      <p>Regards,</p>
      <p>${enterpriseName}</p>
    `;
 
    // Define email parameters
    const emailParams = {
      Destination: { ToAddresses: [messageTo] },
      Message: {
        Body: {
          Html: { Charset: 'UTF-8', Data: body },
        },
        Subject: { Charset: 'UTF-8', Data: subject },
      },
      Source: process.env.AWS_SOURCE_EMAIL,
    };
 
    console.log('Sending email...');
    const sendEmailCommand = new SendEmailCommand(emailParams);
    const response = await sesClient.send(sendEmailCommand);
 
    console.log('Email sent successfully:', response);
    return response;
  } catch (error) {
    console.error('Error sending email:', error.message);
    throw error;
  }
};
 
module.exports = { sendEmail };